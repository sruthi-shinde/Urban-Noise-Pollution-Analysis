# =============================================================================
# 07_anomaly.R  |  Detect unusual noise events (ensemble of 3 methods + voting)
#   A  Robust z-score (median/MAD) vs the station's own hour-of-day & weekend baseline
#   B  Tukey IQR fence vs the same baseline
#   C  Regression residual (what the traffic/weather/station model cannot explain)
# An hour is flagged if >= min_votes methods agree; consecutive flagged hours
# are merged into EVENTS; very short blips (< min_duration_h) are discarded.
# =============================================================================
source("R/00_setup.R")
A <- CFG$anomaly
d <- load_clean() |> filter(!is.na(noise_db)) |>
  mutate(traffic_db = 10 * log10(traffic_count + 1), is_night = as.integer(period == "Night"),
         rain_flag = as.integer(rainfall_mm > 0))

# ---- Method A + B: per station / hour / weekend baseline ---------------------
d <- d |> group_by(station_id, hour, is_weekend) |>
  mutate(base_med = median(noise_db), base_mad = pmax(mad(noise_db), 0.5),
         q1 = quantile(noise_db, 0.25), q3 = quantile(noise_db, 0.75),
         robust_z = (noise_db - base_med) / base_mad,
         flag_A = robust_z > A$robust_z,
         flag_B = noise_db > q3 + A$iqr_mult * (q3 - q1)) |> ungroup()

# ---- Method C: regression residuals ------------------------------------------
fit <- lm(noise_db ~ station_id * is_night + factor(hour) + traffic_db + rain_flag + wind_speed_ms, data = d, na.action = na.exclude)
res <- residuals(fit)
d$resid <- as.numeric(res)
d$resid_z <- (d$resid - median(d$resid, na.rm = TRUE)) / mad(d$resid, na.rm = TRUE)
d$flag_C <- !is.na(d$resid_z) & d$resid_z > A$resid_z
rm(fit, res)

d <- d |> mutate(votes = flag_A + flag_B + flag_C, flagged = votes >= A$min_votes)
method_tab <- tibble(
  metric = c("Flagged by A (robust z)", "Flagged by B (IQR)", "Flagged by C (residual)", "Flagged by >= 2 methods (consensus)", "Flagged by all 3"),
  hours = c(sum(d$flag_A), sum(d$flag_B), sum(d$flag_C), sum(d$flagged), sum(d$votes == 3)),
  pct_of_hours = round(100 * hours / nrow(d), 2))
save_table(method_tab, "20_anomaly_method_agreement")

# ---- Merge flagged hours into events -----------------------------------------
events <- d |> filter(flagged) |> arrange(station_id, timestamp) |> group_by(station_id) |>
  mutate(gap_h = as.numeric(difftime(timestamp, lag(timestamp), units = "hours")),
         event_no = cumsum(is.na(gap_h) | gap_h > A$merge_gap_h + 1)) |> ungroup() |>
  group_by(station_id, station_name, zone_type, event_no) |>
  summarise(start = min(timestamp), end = max(timestamp), n_flagged_hours = n(),
            peak_db = max(noise_db), peak_excess_over_baseline = max(noise_db - base_med),
            mean_excess_over_limit = mean(pmax(excess_db, 0)), peak_robust_z = max(robust_z),
            any_holiday = any(is_holiday), starts_at_night = hour(min(timestamp)) %in% c(22:23, 0:5), .groups = "drop") |>
  mutate(duration_h = as.numeric(difftime(end, start, units = "hours")) + 1) |>
  filter(duration_h >= A$min_duration_h) |>
  mutate(severity = case_when(peak_excess_over_baseline >= 15 ~ "Severe", peak_excess_over_baseline >= 10 ~ "Moderate", TRUE ~ "Mild"),
         context = case_when(any_holiday ~ "Festival / holiday-day event", starts_at_night ~ "Night-time disturbance", TRUE ~ "Daytime disturbance")) |>
  arrange(desc(peak_excess_over_baseline)) |> mutate(event_id = sprintf("E%02d", row_number())) |>
  select(event_id, station_id, station_name, zone_type, start, end, duration_h, peak_db, peak_excess_over_baseline,
         mean_excess_over_limit, severity, context) |>
  mutate(across(where(is.numeric), ~ round(.x, 1)))
save_table(events |> mutate(start = format(start), end = format(end)), "21_detected_noise_events")
saveRDS(events, "data/processed/events.rds")

# ---- Validation against injected ground truth (simulated data only) ----------
if (file.exists(CFG$truth_file)) {
  tr <- read_csv(CFG$truth_file, show_col_types = FALSE, col_types = cols(.default = col_character(), magnitude_db = col_double())) |>
    mutate(start = ymd_hms(start, tz = CFG$tz), end = ymd_hms(end, tz = CFG$tz))
  ov <- inner_join(events |> select(event_id, station_id, ds = start, de = end),
                   tr |> mutate(tid = row_number()) |> select(tid, station_id, ts = start, te = end), by = "station_id",
                   relationship = "many-to-many") |> filter(ds <= te, de >= ts)
  recall    <- n_distinct(ov$tid) / nrow(tr)
  precision <- n_distinct(ov$event_id) / nrow(events)
  # hour-level
  d$truth <- FALSE
  for (i in seq_len(nrow(tr))) d$truth[d$station_id == tr$station_id[i] & d$timestamp >= tr$start[i] & d$timestamp <= tr$end[i]] <- TRUE
  d$in_event <- FALSE
  for (i in seq_len(nrow(events))) d$in_event[d$station_id == events$station_id[i] & d$timestamp >= events$start[i] & d$timestamp <= events$end[i]] <- TRUE
  tp <- sum(d$truth & d$in_event); fp <- sum(!d$truth & d$in_event); fn <- sum(d$truth & !d$in_event)
  valid <- tibble(metric = c("True events injected", "Events detected", "Event-level recall", "Event-level precision",
                             "Hour-level precision", "Hour-level recall", "Hour-level F1"),
                  value = round(c(nrow(tr), nrow(events), recall, precision, tp / (tp + fp), tp / (tp + fn),
                                  2 * tp / (2 * tp + fp + fn)), 3))
  save_table(valid, "22_anomaly_validation"); print(valid)
  missed <- tr |> mutate(tid = row_number()) |> filter(!tid %in% ov$tid) |> select(-tid)
  save_table(missed |> mutate(start = format(start), end = format(end)), "23_missed_events")
}

# ---- Figures -----------------------------------------------------------------
p1 <- ggplot(events, aes(start, reorder(station_name, as.numeric(factor(zone_type))), colour = severity, size = duration_h)) +
  geom_point(alpha = 0.8) +
  scale_colour_manual(values = c(Mild = "#F4D03F", Moderate = "#E67E22", Severe = "#C0392B")) +
  scale_size_continuous(range = c(2, 7)) +
  labs(title = "Detected abnormal noise events through 2024", x = NULL, y = NULL, colour = "Severity", size = "Hours") + theme_noise()
save_plot(p1, "19_anomaly_timeline", h = 6)

top <- events[1, ]
win <- d |> filter(station_id == top$station_id, timestamp >= top$start - hours(36), timestamp <= top$end + hours(36))
p2 <- ggplot(win, aes(timestamp)) + geom_ribbon(aes(ymin = base_med - 2 * base_mad, ymax = base_med + 2 * base_mad), fill = "grey80") +
  geom_line(aes(y = base_med), colour = "grey40", linetype = "dashed") + geom_line(aes(y = noise_db), colour = "#2C3E50") +
  geom_point(data = filter(win, flagged), aes(y = noise_db), colour = "#C0392B", size = 2.5) +
  labs(title = sprintf("Closer look: event %s at %s", top$event_id, top$station_name),
       subtitle = "Dashed = typical level for this hour (median), grey band = +/- 2 MAD, red = flagged hours",
       x = NULL, y = "dB(A)") + theme_noise()
save_plot(p2, "20_anomaly_example", w = 10, h = 5)

p3 <- events |> mutate(onset_hour = hour(start)) |> ggplot(aes(onset_hour, fill = zone_type)) + geom_bar() +
  scale_fill_manual(values = ZONE_COLS) + scale_x_continuous(breaks = seq(0, 23, 3), limits = c(-0.5, 23.5)) +
  labs(title = "When do abnormal events start?", x = "Onset hour", y = "Events", fill = "Zone") + theme_noise()
save_plot(p3, "21_anomaly_onset_hours", h = 4.5)

print(method_tab); print(count(events, severity)); print(count(events, zone_type))
msg("Anomaly detection complete: ", nrow(events), " events")
