# =============================================================================
# 08_insights.R  |  Turn the result tables into plain-language findings
# Every number below is read from outputs/tables, so insights update
# automatically whenever the data or parameters change.
# =============================================================================
source("R/00_setup.R")
rd <- function(f) read_csv(file.path("outputs/tables", paste0(f, ".csv")), show_col_types = FALSE)

by_zone <- rd("02_summary_by_zone");  by_st <- rd("02_summary_by_station")
peaks   <- rd("12_peak_hours_by_zone"); dn <- rd("04_day_vs_night_by_zone"); wk <- rd("05_weekday_vs_weekend_by_zone")
comp    <- rd("10_compliance_by_zone_period"); hot <- rd("17_hotspot_ranking"); coefs <- rd("07_regression_coefficients")
perf    <- rd("08_regression_performance"); cor_t <- rd("06_noise_correlations"); ev <- rd("21_detected_noise_events")
clog    <- rd("01_cleaning_log"); clu <- rd("19_station_clusters")
val     <- if (file.exists("outputs/tables/22_anomaly_validation.csv")) rd("22_anomaly_validation") else NULL

loud <- by_zone |> slice_max(Leq, n = 1); quiet <- by_zone |> slice_min(Leq, n = 1)
worst_all   <- comp |> slice_max(pct_exceed, n = 1)
trafficb    <- coefs |> filter(term == "traffic_db") |> pull(estimate)
rain_b      <- coefs |> filter(term == "rain_flag") |> pull(estimate)
rho_tr      <- cor_t |> filter(variable == "traffic_count") |> pull(spearman_rho)
n_comp_viol <- comp |> filter(pct_exceed > 50) |> nrow()
top3 <- hot |> slice_head(n = 3)
ind_we <- wk |> filter(zone_type == "Industrial") |> pull(weekend_minus_weekday)
dn_all <- mean(dn$day_minus_night)
day_exc <- 100 * sum(comp$n_exceed[comp$period == "Day"]) / sum(comp$n[comp$period == "Day"])
night_exc <- 100 * sum(comp$n_exceed[comp$period == "Night"]) / sum(comp$n[comp$period == "Night"])
sil_day <- comp$pct_exceed[comp$zone_type == "Silence" & comp$period == "Day"]
sil_night <- comp$pct_exceed[comp$zone_type == "Silence" & comp$period == "Night"]
p_temp <- coefs$p.value[coefs$term == "temperature_c"]; p_hum <- coefs$p.value[coefs$term == "humidity_pct"]
pk <- peaks |> mutate(txt = sprintf("%s: %02d:00 (%.1f dB)", zone_type, peak_hour, peak_Leq))

ins <- c(
  "# Key Insights - Urban Noise Pollution Pattern Analysis", "",
  "## 1. Where is it loudest?",
  sprintf("- **%s** is the loudest zone (Leq %.1f dB) and **%s** the quietest (Leq %.1f dB), a %.1f dB gap - roughly %.0fx the sound energy.",
          loud$zone_type, loud$Leq, quiet$zone_type, quiet$Leq, loud$Leq - quiet$Leq, 10^((loud$Leq - quiet$Leq) / 10)),
  sprintf("- Top-3 hotspots by composite score: **%s** (%.0f), **%s** (%.0f), **%s** (%.0f).",
          top3$station_name[1], top3$hotspot_score[1], top3$station_name[2], top3$hotspot_score[2], top3$station_name[3], top3$hotspot_score[3]), "",
  "## 2. When is it loudest?",
  sprintf("- Peak hours by zone - %s.", paste(pk$txt, collapse = "; ")),
  sprintf("- Noise is on average %.1f dB higher by day than by night. Share of hours above the limit: %.0f%% by day vs %.0f%% by night (night limits are 5-10 dB stricter than day limits).", dn_all, day_exc, night_exc),
  sprintf("- Industrial noise drops by %.1f dB at weekends, i.e. it follows working shifts; commercial zones do not quieten.", abs(ind_we)), "",
  "## 3. Legal compliance (Noise Rules 2000)",
  sprintf("- Worst case: **%s, %s** - %.0f%% of hours exceed the limit.", worst_all$zone_type, tolower(worst_all$period), worst_all$pct_exceed),
  sprintf("- %d of 8 zone-period combinations breach the limit in more than half of all hours.", n_comp_viol),
  sprintf("- Silence zones (hospitals, courts, colleges) exceed their limit in %.0f%% of daytime and %.0f%% of night-time hours.", sil_day, sil_night), "",
  "## 4. What drives noise?",
  sprintf("- Traffic is the dominant driver (Spearman rho = %.2f). In the regression each +1 dB of traffic intensity (10*log10 vehicles) adds %.2f dB, i.e. a doubling of traffic adds about %.1f dB.",
          rho_tr, trafficb, trafficb * 10 * log10(2)),
  sprintf("- The model explains %.0f%% of variance on held-out Oct-Dec data (RMSE %.1f dB), so it generalises in time.", 100 * perf$R2[2], perf$RMSE[2]),
  sprintf("- Rain adds %.1f dB. Temperature (p = %.2f) and humidity (p = %.2f) %s once traffic is controlled; their raw correlations mostly reflect the shared daily cycle.",
          rain_b, p_temp, p_hum, ifelse(max(p_temp, p_hum) > 0.05, "have no significant independent effect", "keep a small independent effect")), "",
  "## 5. Unusual events",
  sprintf("- %d abnormal noise events detected (%d severe). The 1 Nov festival evening shows up at all residential and commercial stations.",
          nrow(ev), sum(ev$severity == "Severe")),
  if (!is.null(val)) sprintf("- Validation on injected events: event recall %.0f%%, event precision %.0f%%, hour-level F1 %.2f. Lower precision means some alerts are false alarms - tune thresholds in CFG$anomaly.",
          100 * val$value[val$metric == "Event-level recall"], 100 * val$value[val$metric == "Event-level precision"], val$value[val$metric == "Hour-level F1"]), "",
  "## 6. Data quality",
  sprintf("- %d duplicate rows, %d invalid sensor readings and %d zone-label inconsistencies were repaired; short gaps were interpolated and long gaps excluded.",
          clog$rows_affected[clog$step == "Duplicate station-hour rows"], clog$rows_affected[clog$step == "Noise outside valid range"],
          clog$rows_affected[clog$step == "Inconsistent zone labels"]), "",
  "## 7. Recommendations",
  sprintf("- Prioritise enforcement and traffic management around **%s** and **%s** (highest hotspot scores).", top3$station_name[1], top3$station_name[2]),
  "- Introduce night-time heavy-vehicle restrictions and honking enforcement on commercial corridors.",
  "- Protect silence zones with no-honking signage, speed calming and diversion of through-traffic.",
  "- Use the anomaly detector as a live alert: sustained +10 dB events trigger inspection (construction, generators, gatherings).", "",
  "## Limitations",
  "- Data are simulated (calibrated to realistic traffic-noise physics); conclusions about a real city require real monitor data.",
  "- Hourly observations are autocorrelated; p-values with n ~ 100,000 are therefore optimistic. Effect sizes and daily-aggregated tests are more trustworthy.",
  "- Traffic and night/day are partly collinear (VIF about 8 and 5), so individual coefficients should be read with care.",
  "- Precision of the anomaly detector depends on thresholds; it flags statistical, not necessarily harmful, events."
)
writeLines(ins, "outputs/insights.md"); cat(ins, sep = "\n")
