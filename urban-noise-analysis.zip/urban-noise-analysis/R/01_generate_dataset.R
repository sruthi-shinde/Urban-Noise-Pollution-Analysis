# =============================================================================
# 01_generate_dataset.R  |  Simulate a realistic hourly urban noise dataset
# -----------------------------------------------------------------------------
# WHY SIMULATE?  Continuous hourly data from many stations is hard to obtain.
# The simulator reproduces the physics/behaviour of urban noise (traffic-driven
# level L = a + 9*log10(traffic), diurnal rhythm, weekend/holiday effects,
# industrial shifts, weather) AND injects known events + data-quality problems,
# so every analysis step can be verified against ground truth.
# To use real data (e.g. CPCB National Ambient Noise Monitoring Network), skip
# this script and place the CSV at CFG$raw_file (see README, "Using real data").
# =============================================================================
source("R/00_setup.R")
set.seed(CFG$seed)

stations <- tibble::tribble(
  ~station_id, ~station_name,              ~zone_type,    ~latitude, ~longitude, ~offset_db,
  "S01", "Industrial Estate North",        "Industrial",  21.205,    79.060,      0,
  "S02", "Factory Cluster East",           "Industrial",  21.170,    79.130,     -1,
  "S03", "Logistics Yard",                 "Industrial",  21.120,    79.100,      3,
  "S04", "Central Market",                 "Commercial",  21.146,    79.085,      1,
  "S05", "Railway Station Road",           "Commercial",  21.152,    79.092,      4,
  "S06", "Mall Junction",                  "Commercial",  21.130,    79.050,     -1,
  "S07", "Green Park Colony",              "Residential", 21.100,    79.020,      0,
  "S08", "Lakeview Apartments",            "Residential", 21.180,    79.040,     -1,
  "S09", "Old Town Lane",                  "Residential", 21.140,    79.110,      3,
  "S10", "City Hospital",                  "Silence",     21.160,    79.070,      3,
  "S11", "Government College",             "Silence",     21.125,    79.075,      0,
  "S12", "Court Complex",                  "Silence",     21.150,    79.060,     -1
)
zone_par <- tibble::tribble(
  ~zone_type,    ~a_db, ~peak_traffic, ~weekend_factor,
  "Industrial",   44,    600,           0.40,
  "Commercial",   39,   1500,           1.10,
  "Residential",  33,    300,           0.90,
  "Silence",      29,    150,           0.50
)
# Relative traffic intensity by hour of day (double rush-hour peak)
traffic_profile <- c(0.08,0.05,0.04,0.04,0.07,0.18,0.45,0.85,1.00,0.80,0.65,0.65,
                     0.70,0.65,0.65,0.70,0.85,1.00,0.95,0.75,0.55,0.38,0.25,0.14)

hours <- seq(as.POSIXct("2024-01-01 00:00:00", tz = CFG$tz), by = "hour", length.out = 8784)  # 2024 = leap year

# ---- City-wide weather -------------------------------------------------------
doy <- yday(hours); hr <- hour(hours); mon <- month(hours)
monsoon <- mon %in% 6:9
weather <- tibble(
  timestamp     = hours,
  temperature_c = 27 + 8 * sin(2 * pi * (doy - 100) / 366) + 4 * sin(2 * pi * (hr - 9) / 24) + rnorm(8784, 0, 1),
  rainfall_mm   = rbinom(8784, 1, ifelse(monsoon, 0.12, 0.01)) * round(rexp(8784, 0.6), 1)
) |>
  mutate(humidity_pct  = pmin(100, pmax(20, 55 + 20 * sin(2 * pi * (doy - 170) / 366) -
                                          (temperature_c - 27) + 15 * (rainfall_mm > 0) + rnorm(8784, 0, 5))),
         wind_speed_ms = pmax(0, rnorm(8784, 2.5 + 0.8 * sin(2 * pi * (doy - 60) / 366), 1.2)))

# ---- Station x hour grid -----------------------------------------------------
grid <- tidyr::expand_grid(stations, timestamp = hours) |>
  left_join(zone_par, by = "zone_type") |>
  left_join(weather, by = "timestamp") |>
  mutate(hour = hour(timestamp), date = as.Date(timestamp, tz = CFG$tz),
         weekend = wday(date, week_start = 1) >= 6,
         holiday = date %in% CFG$holidays,
         wf = if_else(weekend | holiday, weekend_factor, 1))

day_eff <- grid |> distinct(station_id, date) |>
  mutate(day_eff = rnorm(n(), 0, 1.5), day_traf = rlnorm(n(), 0, 0.12))
grid <- left_join(grid, day_eff, by = c("station_id", "date")) |>
  mutate(traffic_count = rpois(n(), peak_traffic * traffic_profile[hour + 1] * wf * day_traf),
         industrial_shift = if_else(zone_type == "Industrial" & !weekend & !holiday & hour %in% 8:17, 4, 0),
         noise_true = a_db + offset_db + 0.9 * 10 * log10(traffic_count + 1) + industrial_shift +
                      0.8 * (rainfall_mm > 0) + 0.25 * wind_speed_ms + day_eff + rnorm(n(), 0, 2))

# ---- Inject known noise events (ground truth for anomaly detection) ---------
events <- bind_rows(
  # Festival fireworks on 1 Nov 2024, 19:00-23:00 at residential & commercial stations
  stations |> filter(zone_type %in% c("Residential", "Commercial")) |>
    transmute(station_id,
              start = as.POSIXct("2024-11-01 19:00:00", tz = CFG$tz),
              end   = as.POSIXct("2024-11-01 23:00:00", tz = CFG$tz),
              type = "festival_fireworks", magnitude_db = 10),
  # 18 random local events
  tibble(station_id = sample(stations$station_id, 18, replace = TRUE),
         start = sample(hours[1:(length(hours) - 12)], 18),
         dur_h = sample(3:8, 18, replace = TRUE),
         type = sample(c("construction", "traffic_jam_honking", "public_gathering", "generator"), 18, replace = TRUE),
         magnitude_db = round(runif(18, 8, 14), 1)) |>
    mutate(end = start + hours(dur_h - 1)) |> select(-dur_h)
)
for (i in seq_len(nrow(events))) {
  idx <- grid$station_id == events$station_id[i] & grid$timestamp >= events$start[i] & grid$timestamp <= events$end[i]
  grid$noise_true[idx] <- grid$noise_true[idx] + events$magnitude_db[i]
}
write_csv(events |> mutate(start = format(start, "%Y-%m-%d %H:%M:%S"), end = format(end, "%Y-%m-%d %H:%M:%S")),
          CFG$truth_file)

# ---- Corrupt the data like a real sensor network would ----------------------
n <- nrow(grid)
raw <- grid |>
  transmute(station_id, station_name, zone_type, latitude, longitude,
            timestamp = format(timestamp, "%Y-%m-%d %H:%M:%S"),
            noise_db = round(noise_true, 1), traffic_count, temperature_c = round(temperature_c, 1),
            humidity_pct = round(humidity_pct, 1), wind_speed_ms = round(wind_speed_ms, 1),
            rainfall_mm, is_holiday = holiday)

# (a) random missing values, short dropouts (1-3 h) and one long outage
raw$noise_db[sample(n, round(0.008 * n))] <- NA
for (s in sample(n - 3, 80)) raw$noise_db[s:(s + sample(1:3, 1))] <- NA
raw$traffic_count[sample(n, round(0.005 * n))] <- NA
raw$temperature_c[sample(n, round(0.003 * n))] <- NA
outage <- raw$station_id == "S07" & raw$timestamp >= "2024-05-10 00:00:00" & raw$timestamp <= "2024-05-12 23:00:00"
raw$noise_db[outage] <- NA; raw$traffic_count[outage] <- NA
# (b) sensor faults: physically impossible readings
bad <- sample(which(!is.na(raw$noise_db)), round(0.0015 * n))
raw$noise_db[bad] <- sample(c(0, -1, 140, 999), length(bad), replace = TRUE)
# (c) inconsistent zone labels and mixed timestamp formats
variants <- list(Industrial = c("industrial ", " INDUSTRIAL", "Ind."), Commercial = c("COMMERCIAL", "commercial", "Comm."),
                 Residential = c(" residential", "RESIDENTIAL", "Resi."), Silence = c("silence zone", "SILENCE", "Silent"))
messy <- sample(n, round(0.03 * n))
raw$zone_type[messy] <- vapply(raw$zone_type[messy], function(z) sample(variants[[z]], 1), character(1))
alt <- sample(n, round(0.005 * n))
raw$timestamp[alt] <- format(as.POSIXct(raw$timestamp[alt], tz = CFG$tz), "%d/%m/%Y %H:%M")
# (d) duplicated rows
raw <- bind_rows(raw, raw[sample(n, 60), ])

write_csv(raw, CFG$raw_file)
msg("Raw dataset written: ", nrow(raw), " rows x ", ncol(raw), " cols -> ", CFG$raw_file)
msg("Ground-truth events written: ", nrow(events), " -> ", CFG$truth_file)
