# =============================================================================
# 05_statistics.R  |  Inferential statistics & predictive modelling
#   1 Normality   2 Zone differences   3 Day vs night   4 Weekday vs weekend
#   5 Correlations   6 Regression (train/test)   7 Legal compliance
# =============================================================================
source("R/00_setup.R")
set.seed(CFG$seed)
d <- load_clean() |> filter(!is.na(noise_db))
fmt_p <- function(p) ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
tests <- tibble(test = character(), question = character(), statistic = character(), p_value = character(), conclusion = character())
add_test <- function(test, question, stat, p, concl)
  tests <<- add_row(tests, test = test, question = question, statistic = stat, p_value = fmt_p(p), conclusion = concl)

# ---- 1. Normality (decides parametric vs non-parametric tests) ---------------
smp <- slice_sample(d, n = 5000)
sh  <- shapiro.test(smp$noise_db)
add_test("Shapiro-Wilk (n=5000 sample)", "Is noise normally distributed?", sprintf("W = %.3f", sh$statistic), sh$p.value,
         ifelse(sh$p.value < 0.05, "Not normal -> use non-parametric tests", "Approximately normal"))
pq <- ggplot(smp, aes(sample = noise_db)) + stat_qq(alpha = 0.3, size = 0.6) + stat_qq_line(colour = "red") +
  facet_wrap(~zone_type, scales = "free") + labs(title = "Normal Q-Q plots by zone", x = "Theoretical", y = "Observed dB(A)") + theme_noise()
save_plot(pq, "07_qq_plots")

# ---- 2. Difference between zones ---------------------------------------------
kw <- kruskal.test(noise_db ~ zone_type, data = d)
eps2 <- unname(kw$statistic) / (nrow(d) - 1)   # epsilon-squared effect size
add_test("Kruskal-Wallis", "Do zones differ in noise level?", sprintf("H = %.0f, df = %d, eps2 = %.2f", kw$statistic, kw$parameter, eps2),
         kw$p.value, "Zones differ significantly (very large effect)")
pw <- pairwise.wilcox.test(d$noise_db, d$zone_type, p.adjust.method = "BH", exact = FALSE) |> tidy() |>
  mutate(p.adj = fmt_p(p.value)) |> select(group1, group2, p.adj)
save_table(pw, "03_pairwise_zone_tests")

# ---- 3. Day vs night (paired by station-date) --------------------------------
daily <- d |> group_by(station_id, zone_type, date, period) |> summarise(Leq = leq(noise_db), .groups = "drop") |>
  pivot_wider(names_from = period, values_from = Leq) |> drop_na(Day, Night)
wd <- wilcox.test(daily$Day, daily$Night, paired = TRUE, exact = FALSE)
add_test("Paired Wilcoxon", "Is daytime louder than night (same station & date)?",
         sprintf("mean diff = %.1f dB", mean(daily$Day - daily$Night)), wd$p.value, "Day significantly louder than night")
dn_zone <- daily |> group_by(zone_type) |>
  summarise(mean_day = leq(Day), mean_night = leq(Night), day_minus_night = mean(Day - Night),
            p_value = fmt_p(wilcox.test(Day, Night, paired = TRUE, exact = FALSE)$p.value), .groups = "drop") |>
  mutate(across(where(is.numeric), ~ round(.x, 2)))
save_table(dn_zone, "04_day_vs_night_by_zone")

# ---- 4. Weekday vs weekend (by zone) ----------------------------------------
wk <- d |> group_by(station_id, zone_type, date, is_weekend) |> summarise(Leq = leq(noise_db), .groups = "drop") |>
  group_by(zone_type) |> group_modify(~ {
    w <- wilcox.test(Leq ~ is_weekend, data = .x, exact = FALSE)
    tibble(weekday_Leq = leq(.x$Leq[!.x$is_weekend]), weekend_Leq = leq(.x$Leq[.x$is_weekend]), p_raw = w$p.value)
  }) |> ungroup() |>
  mutate(weekend_minus_weekday = weekend_Leq - weekday_Leq, p_BH = p.adjust(p_raw, "BH"), p_value = fmt_p(p_BH)) |>
  select(-p_raw, -p_BH) |> mutate(across(where(is.numeric), ~ round(.x, 2)))
save_table(wk, "05_weekday_vs_weekend_by_zone")
add_test("Wilcoxon rank-sum per zone (BH-adjusted)", "Does the weekend differ from weekdays?", "see table 05", 0,
         "Industrial quieter at weekends; commercial slightly louder")
tests$p_value[nrow(tests)] <- "see table"

# ---- 5. Correlations ---------------------------------------------------------
vars <- c("traffic_count", "temperature_c", "humidity_pct", "wind_speed_ms", "rainfall_mm")
cd <- d |> select(noise_db, all_of(vars)) |> drop_na()
cor_tab <- bind_rows(lapply(vars, function(v) {
  ct <- cor.test(cd$noise_db, cd[[v]], method = "spearman", exact = FALSE)
  tibble(variable = v, spearman_rho = unname(ct$estimate), p_value = fmt_p(ct$p.value))
})) |> mutate(spearman_rho = round(spearman_rho, 3))
save_table(cor_tab, "06_noise_correlations")
cor_zone <- d |> drop_na(traffic_count) |> group_by(zone_type) |>
  summarise(rho_traffic = round(cor(noise_db, traffic_count, method = "spearman"), 3), .groups = "drop")
save_table(cor_zone, "06b_traffic_correlation_by_zone")
cm <- cor(cd, method = "spearman")
png("outputs/figures/08_correlation_matrix.png", 1100, 1000, res = 150)
corrplot(cm, method = "color", type = "upper", addCoef.col = "black", tl.col = "black", number.cex = 0.8,
         col = colorRampPalette(c("#2E86C1", "white", "#C0392B"))(200), diag = FALSE,
         title = "Spearman correlation matrix", mar = c(0, 0, 2, 0))
dev.off()

# ---- 6. Multiple linear regression (time-based train/test split) -------------
md <- d |> drop_na(traffic_count, temperature_c) |>
  mutate(traffic_db = 10 * log10(traffic_count + 1), is_night = as.integer(period == "Night"),
         weekend_i = as.integer(is_weekend), rain_flag = as.integer(rainfall_mm > 0))
train <- filter(md, date <= CFG$train_cutoff); test <- filter(md, date > CFG$train_cutoff)
f <- noise_db ~ traffic_db + zone_type + is_night + weekend_i + temperature_c + humidity_pct + wind_speed_ms + rain_flag
m <- lm(f, data = train)
coefs <- tidy(m, conf.int = TRUE) |> mutate(across(where(is.numeric), ~ round(.x, 4)))
save_table(coefs, "07_regression_coefficients")
pred <- predict(m, test)
perf <- tibble(set = c("Train (Jan-Sep)", "Test (Oct-Dec)"),
               n = c(nrow(train), nrow(test)),
               R2 = c(summary(m)$r.squared, 1 - sum((test$noise_db - pred)^2) / sum((test$noise_db - mean(test$noise_db))^2)),
               RMSE = c(sqrt(mean(resid(m)^2)), sqrt(mean((test$noise_db - pred)^2))),
               MAE  = c(mean(abs(resid(m))), mean(abs(test$noise_db - pred)))) |> mutate(across(where(is.numeric), ~ round(.x, 3)))
save_table(perf, "08_regression_performance")
X <- model.matrix(f, train)[, -1]
vif <- tibble(term = colnames(X), VIF = sapply(seq_len(ncol(X)), function(j) 1 / (1 - summary(lm(X[, j] ~ X[, -j]))$r.squared))) |>
  mutate(VIF = round(VIF, 2))
save_table(vif, "09_regression_vif")
add_test("Multiple linear regression", "Which factors explain noise level?",
         sprintf("test R2 = %.2f, RMSE = %.2f dB", perf$R2[2], perf$RMSE[2]), 0, "Traffic, zone and night/day dominate")
tests$p_value[nrow(tests)] <- "<0.001"

rd <- tibble(fitted = fitted(m), resid = resid(m)) |> slice_sample(n = 5000)
pr1 <- ggplot(rd, aes(fitted, resid)) + geom_point(alpha = 0.25, size = 0.7) + geom_hline(yintercept = 0, colour = "red") +
  geom_smooth(se = FALSE, colour = "#2E86C1") + labs(title = "Residuals vs fitted", x = "Fitted dB(A)", y = "Residual") + theme_noise()
pr2 <- ggplot(rd, aes(sample = resid)) + stat_qq(alpha = 0.3, size = 0.7) + stat_qq_line(colour = "red") +
  labs(title = "Residual Q-Q plot", x = "Theoretical", y = "Residual") + theme_noise()
pr3 <- ggplot(slice_sample(tibble(obs = test$noise_db, pred = pred), n = 5000), aes(pred, obs)) +
  geom_point(alpha = 0.25, size = 0.7) + geom_abline(colour = "red") + coord_equal() +
  labs(title = "Held-out test set: observed vs predicted", x = "Predicted dB(A)", y = "Observed dB(A)") + theme_noise()
save_plot(pr1, "09_residuals_vs_fitted", 7, 5); save_plot(pr2, "10_residual_qq", 6, 5); save_plot(pr3, "11_observed_vs_predicted", 6.5, 6)

# ---- 7. Legal compliance (Wilson 95% CI) -------------------------------------
comp <- d |> group_by(zone_type, period) |>
  summarise(n = n(), n_exceed = sum(exceed), limit_db = first(limit_db),
            mean_excess_when_exceeding = mean(excess_db[exceed]), .groups = "drop") |>
  mutate(pct_exceed = 100 * n_exceed / n, ci_low = 100 * wilson_lo(n_exceed, n), ci_high = 100 * wilson_hi(n_exceed, n)) |>
  mutate(across(where(is.numeric), ~ round(.x, 2)))
save_table(comp, "10_compliance_by_zone_period")
pc <- ggplot(comp, aes(zone_type, pct_exceed, fill = period)) +
  geom_col(position = position_dodge(0.8), width = 0.75) +
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high), position = position_dodge(0.8), width = 0.25) +
  scale_fill_manual(values = c(Day = "#F4D03F", Night = "#5D6D7E")) +
  labs(title = "Share of hours exceeding the legal limit", subtitle = "Bars = %, whiskers = Wilson 95% CI",
       x = NULL, y = "% of hours above limit", fill = NULL) + theme_noise()
save_plot(pc, "12_compliance_exceedance")

save_table(tests, "11_statistical_tests_summary")
print(tests, width = 140); print(perf); print(cor_tab)
msg("Statistics complete")
