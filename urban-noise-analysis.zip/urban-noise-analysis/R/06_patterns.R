# =============================================================================
# 06_patterns.R  |  Noise pattern analysis: peaks, seasons, hotspots, clustering
# =============================================================================
source("R/00_setup.R")
set.seed(CFG$seed)
d <- load_clean() |> filter(!is.na(noise_db))

# ---- 1. Peak & quiet hours ---------------------------------------------------
zone_hour <- d |> group_by(zone_type, hour) |> summarise(Leq = leq(noise_db), .groups = "drop")
peaks_zone <- zone_hour |> group_by(zone_type) |>
  summarise(peak_hour = hour[which.max(Leq)], peak_Leq = max(Leq), quietest_hour = hour[which.min(Leq)],
            quietest_Leq = min(Leq), daily_range_db = peak_Leq - quietest_Leq, .groups = "drop") |>
  mutate(across(where(is.numeric), ~ round(.x, 2)))
save_table(peaks_zone, "12_peak_hours_by_zone")

station_hour <- d |> group_by(station_id, station_name, zone_type, hour) |> summarise(Leq = leq(noise_db), .groups = "drop")
peaks_station <- station_hour |> group_by(station_id, station_name) |> slice_max(Leq, n = 3, with_ties = FALSE) |>
  summarise(top3_peak_hours = paste(sort(hour), collapse = ", "), .groups = "drop")
save_table(peaks_station, "13_peak_hours_by_station")

slot <- d |> group_by(zone_type, time_slot) |> summarise(Leq = leq(noise_db), pct_exceed = 100 * mean(exceed), .groups = "drop") |>
  mutate(across(where(is.numeric), ~ round(.x, 2)))
save_table(slot, "14_noise_by_time_slot")

# ---- 2. Station x hour fingerprint -------------------------------------------
st_order <- d |> group_by(station_name) |> summarise(L = leq(noise_db)) |> arrange(L) |> pull(station_name) |> as.character()
p1 <- station_hour |> mutate(station_name = factor(station_name, levels = st_order)) |>
  ggplot(aes(hour, station_name, fill = Leq)) + geom_tile() + scale_fill_viridis_c(option = "inferno") +
  scale_x_continuous(breaks = seq(0, 23, 3)) +
  labs(title = "Noise fingerprint of every monitoring station", x = "Hour of day", y = NULL, fill = "Leq dB(A)") + theme_noise()
save_plot(p1, "13_station_hour_fingerprint", h = 6)

# ---- 3. Seasonal and day-type patterns ----------------------------------------
season <- d |> group_by(zone_type, season) |> summarise(Leq = leq(noise_db), .groups = "drop")
p2 <- ggplot(season, aes(season, Leq, fill = zone_type)) + geom_col(position = "dodge") +
  scale_fill_manual(values = ZONE_COLS) + coord_cartesian(ylim = c(35, NA)) +
  labs(title = "Seasonal noise levels by zone", x = NULL, y = "Leq, dB(A)", fill = "Zone") + theme_noise()
save_plot(p2, "14_seasonal_noise")
save_table(mutate(season, Leq = round(Leq, 2)), "15_seasonal_noise")

daytype <- d |> group_by(zone_type, day_type) |> summarise(Leq = leq(noise_db), .groups = "drop")
p3 <- ggplot(daytype, aes(zone_type, Leq, fill = day_type)) + geom_col(position = "dodge") +
  scale_fill_manual(values = c(Weekday = "#34495E", Weekend = "#5DADE2", Holiday = "#F39C12")) + coord_cartesian(ylim = c(35, NA)) +
  labs(title = "Weekday vs weekend vs holiday", x = NULL, y = "Leq, dB(A)", fill = NULL) + theme_noise()
save_plot(p3, "15_daytype_noise")
save_table(mutate(daytype, Leq = round(Leq, 2)), "16_daytype_noise")

# ---- 4. Hotspot index --------------------------------------------------------
# Composite 0-100 score; compliance-based indicators weighted higher (legally meaningful)
#   40% mean excess over limit | 40% % hours above limit | 20% Noise Pollution Level (LNP = Leq + 2.56 sigma)
hot <- d |> group_by(station_id, station_name, zone_type, latitude, longitude) |>
  summarise(Leq = leq(noise_db), L10 = L10(noise_db), L90 = L90(noise_db), sd_db = sd(noise_db),
            noise_climate = L10 - L90, LNP = Leq + 2.56 * sd_db, pct_exceed = 100 * mean(exceed),
            mean_excess_db = mean(pmax(excess_db, 0)), .groups = "drop") |>
  mutate(hotspot_score = 100 * (0.4 * rescale(mean_excess_db) + 0.4 * rescale(pct_exceed) + 0.2 * rescale(LNP)),
         severity = case_when(hotspot_score >= 66 ~ "High", hotspot_score >= 33 ~ "Moderate", TRUE ~ "Low"),
         severity = factor(severity, levels = c("High", "Moderate", "Low"))) |>
  arrange(desc(hotspot_score)) |> mutate(rank = row_number()) |>
  mutate(across(where(is.numeric), ~ round(.x, 2)))
save_table(hot, "17_hotspot_ranking")
p4 <- ggplot(hot, aes(longitude, latitude)) +
  geom_point(aes(size = hotspot_score, colour = severity), alpha = 0.8) +
  geom_text(aes(label = station_name), vjust = -1.6, size = 3) +
  scale_colour_manual(values = c(High = "#C0392B", Moderate = "#F39C12", Low = "#27AE60")) +
  scale_size_continuous(range = c(4, 14)) +
  labs(title = "Noise hotspot map (synthetic station coordinates)", subtitle = "Bubble size = hotspot score (0-100)",
       x = "Longitude", y = "Latitude", colour = "Severity", size = "Score") + theme_noise()
save_plot(p4, "16_hotspot_map", h = 6.5)
p5 <- ggplot(hot, aes(reorder(station_name, hotspot_score), hotspot_score, fill = severity)) + geom_col() + coord_flip() +
  scale_fill_manual(values = c(High = "#C0392B", Moderate = "#F39C12", Low = "#27AE60")) +
  labs(title = "Hotspot score ranking", x = NULL, y = "Hotspot score (0-100)", fill = "Severity") + theme_noise()
save_plot(p5, "17_hotspot_ranking", h = 6)

# ---- 5. Cluster stations by 24-hour noise profile (k-means) ------------------
prof <- station_hour |> select(station_id, hour, Leq) |> pivot_wider(names_from = hour, values_from = Leq, names_prefix = "h")
mat <- as.matrix(select(prof, -station_id)); rownames(mat) <- prof$station_id
wss <- tibble(k = 1:6, tot_withinss = sapply(1:6, function(k) kmeans(mat, k, nstart = 25)$tot.withinss))
save_table(mutate(wss, tot_withinss = round(tot_withinss, 1)), "18_kmeans_elbow")
km <- kmeans(mat, CFG$kmeans_k, nstart = 50)
rank_lab <- rank(rowMeans(km$centers)); 
clu <- tibble(station_id = rownames(mat), cl = km$cluster) |>
  mutate(cluster = paste0("Profile ", rank_lab[cl], ifelse(rank_lab[cl] == 1, " (quietest)", ifelse(rank_lab[cl] == CFG$kmeans_k, " (loudest)", "")))) |>
  left_join(distinct(d, station_id, station_name, zone_type), by = "station_id") |> select(-cl) |> arrange(cluster, station_name)
save_table(clu, "19_station_clusters")
p6 <- station_hour |> left_join(select(clu, station_id, cluster), by = "station_id") |>
  ggplot(aes(hour, Leq, group = station_id, colour = cluster)) + geom_line(linewidth = 0.9, alpha = 0.85) +
  scale_x_continuous(breaks = seq(0, 23, 3)) +
  labs(title = "Station clusters by 24-hour noise profile (k-means)", x = "Hour", y = "Leq, dB(A)", colour = NULL) + theme_noise()
save_plot(p6, "18_station_clusters")

print(hot |> select(rank, station_name, zone_type, Leq, pct_exceed, hotspot_score, severity)); print(clu); print(peaks_zone)
msg("Pattern analysis complete")
