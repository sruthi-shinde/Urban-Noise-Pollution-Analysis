# =============================================================================
# 00_setup.R  |  Packages, configuration, helper functions
# Project : Urban Noise Pollution Pattern Analysis Using R
# Requires: R >= 4.1 (native pipe |>)
# =============================================================================

pkgs <- c("dplyr", "tidyr", "ggplot2", "readr", "tibble", "stringr", "forcats",
          "lubridate", "scales", "zoo", "broom", "corrplot")
missing_pkgs <- setdiff(pkgs, rownames(installed.packages()))
if (length(missing_pkgs)) install.packages(missing_pkgs, repos = "https://cloud.r-project.org")
suppressPackageStartupMessages(invisible(lapply(pkgs, library, character.only = TRUE)))

for (p in c("data/raw", "data/processed", "outputs/figures", "outputs/tables"))
  dir.create(p, recursive = TRUE, showWarnings = FALSE)

# ---- Project configuration (change values here, not inside the scripts) -----
CFG <- list(
  raw_file       = "data/raw/urban_noise_raw.csv",
  truth_file     = "data/raw/ground_truth_events.csv",   # only exists for simulated data
  tz             = "Asia/Kolkata",
  seed           = 42,
  valid_range    = c(30, 130),        # physically plausible dB(A) range for outdoor monitors
  max_gap_hours  = 3,                 # gaps up to this length are interpolated; longer stay NA
  train_cutoff   = as.Date("2024-09-30"),   # regression: train Jan-Sep, test Oct-Dec
  holidays       = as.Date(c("2024-01-26", "2024-03-25", "2024-08-15",
                             "2024-10-02", "2024-11-01", "2024-12-25")),
  kmeans_k       = 3,
  anomaly        = list(robust_z = 3, iqr_mult = 1.5, resid_z = 3,
                        min_votes = 2, merge_gap_h = 1, min_duration_h = 2),
  # To use REAL data: map your column names to the project schema, e.g.
  # c(station_id = "Station Code", noise_db = "Leq dB(A)", timestamp = "Date Time")
  column_map     = c()
)

# ---- Permissible limits: Noise Pollution (Regulation and Control) Rules, 2000 (India)
# Day = 06:00-22:00, Night = 22:00-06:00, dB(A) Leq
LIMITS <- tibble::tribble(
  ~zone_type,   ~period, ~limit_db,
  "Industrial",  "Day",   75,
  "Industrial",  "Night", 70,
  "Commercial",  "Day",   65,
  "Commercial",  "Night", 55,
  "Residential", "Day",   55,
  "Residential", "Night", 45,
  "Silence",     "Day",   50,
  "Silence",     "Night", 40
)

ZONES     <- c("Industrial", "Commercial", "Residential", "Silence")
ZONE_COLS <- c(Industrial = "#C0392B", Commercial = "#E67E22",
               Residential = "#2E86C1", Silence = "#27AE60")

# ---- Acoustic helpers --------------------------------------------------------
# Decibels are logarithmic, so the correct "average" is the ENERGY average (Leq),
# not the arithmetic mean of dB values.
leq <- function(x) {
  x <- x[!is.na(x)]
  if (!length(x)) return(NA_real_)
  10 * log10(mean(10^(x / 10)))
}
# Statistical levels: L10 = level exceeded 10% of the time (90th percentile) etc.
L10 <- function(x) as.numeric(quantile(x, 0.90, na.rm = TRUE, names = FALSE))
L50 <- function(x) as.numeric(quantile(x, 0.50, na.rm = TRUE, names = FALSE))
L90 <- function(x) as.numeric(quantile(x, 0.10, na.rm = TRUE, names = FALSE))

wilson_lo <- function(x, n, z = 1.96) { p <- x / n; d <- 1 + z^2 / n
  (p + z^2 / (2 * n) - z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / d }
wilson_hi <- function(x, n, z = 1.96) { p <- x / n; d <- 1 + z^2 / n
  (p + z^2 / (2 * n) + z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2))) / d }

# ---- Plot / file helpers -----------------------------------------------------
theme_noise <- function() {
  theme_minimal(base_size = 12) +
    theme(plot.title = element_text(face = "bold", size = 14),
          plot.subtitle = element_text(colour = "grey35"),
          legend.position = "bottom", panel.grid.minor = element_blank())
}
save_plot  <- function(p, name, w = 9, h = 5.5)
  ggsave(file.path("outputs/figures", paste0(name, ".png")), p, width = w, height = h, dpi = 150, bg = "white")
save_table <- function(df, name) write_csv(df, file.path("outputs/tables", paste0(name, ".csv")))
load_clean <- function() readRDS("data/processed/noise_clean.rds")
msg <- function(...) cat(sprintf("[%s] %s\n", format(Sys.time(), "%H:%M:%S"), paste0(...)))
