# =============================================================================
# 04_eda.R  |  Exploratory data analysis: summaries and first visual look
# =============================================================================
source("R/00_setup.R")
d <- load_clean() |> filter(!is.na(noise_db))

# ---- Summary tables ----------------------------------------------------------
summ <- function(df, ...) df |> group_by(...) |>
  summarise(n = n(), Leq = leq(noise_db), mean_db = mean(noise_db), median_db = median(noise_db),
            sd_db = sd(noise_db), min_db = min(noise_db), max_db = max(noise_db),
            L10 = L10(noise_db), L50 = L50(noise_db), L90 = L90(noise_db),
            pct_exceed = 100 * mean(exceed), .groups = "drop") |> mutate(across(where(is.numeric), ~ round(.x, 2)))
overall    <- d |> mutate(all = "All stations") |> summ(all)
by_zone    <- summ(d, zone_type)
by_station <- summ(d, station_id, station_name, zone_type) |> arrange(desc(Leq))
save_table(overall, "02_summary_overall"); save_table(by_zone, "02_summary_by_zone"); save_table(by_station, "02_summary_by_station")
print(by_zone)

# ---- Figures -----------------------------------------------------------------
p1 <- ggplot(d, aes(noise_db, fill = zone_type)) +
  geom_histogram(bins = 60, colour = "white", linewidth = 0.1) +
  facet_wrap(~zone_type, scales = "free_y") + scale_fill_manual(values = ZONE_COLS, guide = "none") +
  labs(title = "Distribution of hourly noise levels by zone", x = "Noise level, dB(A)", y = "Hours") + theme_noise()
save_plot(p1, "01_noise_distribution_by_zone")

p2 <- ggplot(d, aes(zone_type, noise_db, fill = period)) +
  geom_boxplot(outlier.size = 0.4, outlier.alpha = 0.3, width = 0.65) +
  geom_point(data = LIMITS |> mutate(zone_type = factor(zone_type, levels = ZONES)),
             aes(zone_type, limit_db, group = period), position = position_dodge(width = 0.65),
             shape = 4, size = 3.5, stroke = 1.3, inherit.aes = FALSE) +
  scale_fill_manual(values = c(Day = "#F4D03F", Night = "#5D6D7E")) +
  labs(title = "Noise by zone and period vs legal limits (x)", subtitle = "Noise Pollution (Regulation & Control) Rules, 2000",
       x = NULL, y = "Noise level, dB(A)", fill = NULL) + theme_noise()
save_plot(p2, "02_boxplot_zone_period_limits")

p3 <- ggplot(by_station, aes(reorder(station_name, Leq), Leq, fill = zone_type)) +
  geom_col() + coord_flip() + scale_fill_manual(values = ZONE_COLS) +
  geom_text(aes(label = sprintf("%.1f", Leq)), hjust = -0.15, size = 3.3) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12))) +
  labs(title = "Station ranking by equivalent noise level (Leq)", x = NULL, y = "Leq, dB(A)", fill = "Zone") + theme_noise()
save_plot(p3, "03_station_ranking", h = 6)

hourly <- d |> group_by(zone_type, hour) |> summarise(Leq = leq(noise_db), .groups = "drop")
p4 <- ggplot(hourly, aes(hour, Leq, colour = zone_type)) +
  annotate("rect", xmin = -0.5, xmax = 5.5, ymin = -Inf, ymax = Inf, alpha = 0.08) +
  annotate("rect", xmin = 21.5, xmax = 23.5, ymin = -Inf, ymax = Inf, alpha = 0.08) +
  geom_line(linewidth = 1.1) + geom_point(size = 1.6) + scale_colour_manual(values = ZONE_COLS) +
  scale_x_continuous(breaks = seq(0, 23, 3)) +
  labs(title = "24-hour noise profile by zone", subtitle = "Grey bands = legal night period",
       x = "Hour of day", y = "Leq, dB(A)", colour = "Zone") + theme_noise()
save_plot(p4, "04_hourly_profile_by_zone")

heat <- d |> group_by(zone_type, weekday, hour) |> summarise(Leq = leq(noise_db), .groups = "drop")
p5 <- ggplot(heat, aes(hour, weekday, fill = Leq)) + geom_tile() + facet_wrap(~zone_type) +
  scale_fill_viridis_c(option = "magma") + scale_y_discrete(limits = rev) +
  scale_x_continuous(breaks = seq(0, 23, 6)) +
  labs(title = "When is it loud? Hour x weekday heatmap", x = "Hour of day", y = NULL, fill = "Leq dB(A)") + theme_noise()
save_plot(p5, "05_heatmap_hour_weekday", w = 10, h = 6.5)

monthly <- d |> group_by(zone_type, month) |> summarise(Leq = leq(noise_db), .groups = "drop")
p6 <- ggplot(monthly, aes(month, Leq, colour = zone_type, group = zone_type)) +
  geom_line(linewidth = 1) + geom_point() + scale_colour_manual(values = ZONE_COLS) +
  labs(title = "Monthly noise trend by zone", x = NULL, y = "Leq, dB(A)", colour = "Zone") + theme_noise()
save_plot(p6, "06_monthly_trend")
msg("EDA complete: 6 figures, 3 tables")
