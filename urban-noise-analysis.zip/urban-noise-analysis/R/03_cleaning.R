# =============================================================================
# 03_cleaning.R  |  Data cleaning, imputation, feature engineering
# Every step is logged to outputs/tables/01_cleaning_log.csv (audit trail).
# =============================================================================
source("R/00_setup.R")
raw <- readRDS("data/processed/noise_raw.rds")
clog <- tibble(step = character(), rows_affected = numeric(), action = character())
log_step <- function(step, k, action) clog <<- add_row(clog, step = step, rows_affected = k, action = action)

# 1. Parse timestamps (two formats present) ------------------------------------
d <- raw |> mutate(ts = parse_date_time(timestamp, orders = c("Ymd HMS", "dmY HM", "Ymd HM"),
                                        tz = CFG$tz, quiet = TRUE))
log_step("Mixed timestamp formats", sum(!str_detect(raw$timestamp, "^\\d{4}-")), "Parsed with multiple formats")
log_step("Unparseable timestamps", sum(is.na(d$ts)), "Rows dropped")
d <- filter(d, !is.na(ts))

# 2. Standardise categorical labels --------------------------------------------
d <- d |> mutate(zone_type = case_when(
  str_detect(str_to_lower(str_trim(zone_type)), "^ind") ~ "Industrial",
  str_detect(str_to_lower(str_trim(zone_type)), "^com") ~ "Commercial",
  str_detect(str_to_lower(str_trim(zone_type)), "^res") ~ "Residential",
  str_detect(str_to_lower(str_trim(zone_type)), "^sil") ~ "Silence",
  TRUE ~ NA_character_))
log_step("Inconsistent zone labels", sum(raw$zone_type %in% setdiff(unique(raw$zone_type), ZONES)),
         "Mapped to 4 standard zone types")
stopifnot(!anyNA(d$zone_type))

# 3. Remove duplicate station-hour records -------------------------------------
n0 <- nrow(d); d <- distinct(d, station_id, ts, .keep_all = TRUE)
log_step("Duplicate station-hour rows", n0 - nrow(d), "Removed (kept first)")

# 4. Invalid / impossible values -> NA -----------------------------------------
bad_noise <- !is.na(d$noise_db) & (d$noise_db < CFG$valid_range[1] | d$noise_db > CFG$valid_range[2])
log_step("Noise outside valid range", sum(bad_noise), sprintf("Set to NA (valid: %d-%d dB)", CFG$valid_range[1], CFG$valid_range[2]))
d$noise_db[bad_noise] <- NA
d <- d |> mutate(traffic_count = if_else(traffic_count < 0, NA_real_, traffic_count),
                 humidity_pct  = if_else(humidity_pct < 0 | humidity_pct > 100, NA_real_, humidity_pct))

# 5. Station lookup + complete hourly grid (make gaps explicit) ----------------
lookup <- distinct(d, station_id, station_name, zone_type, latitude, longitude)
stopifnot(nrow(lookup) == n_distinct(lookup$station_id))
full_seq <- seq(min(d$ts), max(d$ts), by = "hour")
full <- d |>
  select(station_id, timestamp = ts, noise_db, traffic_count, temperature_c, humidity_pct, wind_speed_ms, rainfall_mm) |>
  complete(station_id, timestamp = full_seq)
log_step("Missing station-hours (gaps)", sum(is.na(full$noise_db)), "Made explicit; short gaps interpolated")

# 6. Impute short gaps only (<= max_gap_hours) per station ---------------------
impute <- function(x) zoo::na.approx(x, maxgap = CFG$max_gap_hours, na.rm = FALSE)
full <- full |> group_by(station_id) |> arrange(timestamp, .by_group = TRUE) |>
  mutate(noise_was_na = is.na(noise_db),
         across(c(noise_db, traffic_count, temperature_c, humidity_pct, wind_speed_ms, rainfall_mm), impute),
         traffic_count = round(traffic_count),
         imputed = noise_was_na & !is.na(noise_db)) |>
  ungroup() |> select(-noise_was_na)
log_step("Noise values imputed", sum(full$imputed), "Linear interpolation (gap <= 3 h)")
log_step("Noise gaps left as NA", sum(is.na(full$noise_db)), "Gap too long -> excluded from analysis")

# 7. Feature engineering --------------------------------------------------------
clean <- full |> left_join(lookup, by = "station_id") |>
  mutate(date = as.Date(timestamp, tz = CFG$tz), hour = hour(timestamp),
         weekday = wday(date, label = TRUE, abbr = TRUE, week_start = 1, locale = "C"),
         month = month(date, label = TRUE, abbr = TRUE, locale = "C"),
         season = factor(case_when(month(date) %in% c(12, 1, 2) ~ "Winter",
                                   month(date) %in% 3:5 ~ "Summer",
                                   month(date) %in% 6:9 ~ "Monsoon", TRUE ~ "Post-monsoon"),
                         levels = c("Winter", "Summer", "Monsoon", "Post-monsoon")),
         is_weekend = wday(date, week_start = 1) >= 6,
         is_holiday = date %in% CFG$holidays,
         day_type = factor(case_when(is_holiday ~ "Holiday", is_weekend ~ "Weekend", TRUE ~ "Weekday"),
                           levels = c("Weekday", "Weekend", "Holiday")),
         period = if_else(hour >= 6 & hour < 22, "Day", "Night"),
         time_slot = factor(case_when(hour >= 22 | hour < 6 ~ "Night (22-06)", hour < 10 ~ "Morning rush (06-10)",
                                      hour < 16 ~ "Midday (10-16)", hour < 20 ~ "Evening rush (16-20)",
                                      TRUE ~ "Late evening (20-22)"),
                            levels = c("Night (22-06)", "Morning rush (06-10)", "Midday (10-16)",
                                       "Evening rush (16-20)", "Late evening (20-22)")),
         zone_type = factor(zone_type, levels = ZONES)) |>
  left_join(LIMITS |> mutate(zone_type = factor(zone_type, levels = ZONES)), by = c("zone_type", "period")) |>
  mutate(excess_db = noise_db - limit_db, exceed = noise_db > limit_db,
         station_name = factor(station_name)) |>
  arrange(station_id, timestamp)

saveRDS(clean, "data/processed/noise_clean.rds")
write_csv(clean, "data/processed/noise_clean.csv")
save_table(clog, "01_cleaning_log")
msg("Clean dataset: ", nrow(clean), " rows; usable noise readings: ", sum(!is.na(clean$noise_db)))
print(clog, n = Inf, width = 120)
