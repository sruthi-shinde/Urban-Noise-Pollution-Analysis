# =============================================================================
# 02_import.R  |  Import raw data, validate schema, profile the raw file
# =============================================================================
source("R/00_setup.R")

required_cols <- c("station_id", "station_name", "zone_type", "latitude", "longitude",
                   "timestamp", "noise_db", "traffic_count", "temperature_c",
                   "humidity_pct", "wind_speed_ms", "rainfall_mm", "is_holiday")

import_raw <- function(path = CFG$raw_file) {
  stopifnot(file.exists(path))
  df <- read_csv(path, show_col_types = FALSE,
                 col_types = cols(.default = col_double(), station_id = col_character(),
                                  station_name = col_character(), zone_type = col_character(),
                                  timestamp = col_character(), is_holiday = col_logical()))
  if (length(CFG$column_map)) df <- rename(df, any_of(CFG$column_map))   # real-data adapter
  miss <- setdiff(required_cols, names(df))
  if (length(miss)) stop("Missing required columns: ", paste(miss, collapse = ", "))
  df[required_cols]
}

raw <- import_raw()
saveRDS(raw, "data/processed/noise_raw.rds")

overview <- tibble(
  variable   = names(raw),
  type       = vapply(raw, function(x) class(x)[1], character(1)),
  n_missing  = vapply(raw, function(x) sum(is.na(x)), numeric(1)),
  pct_missing = round(100 * n_missing / nrow(raw), 2),
  n_unique   = vapply(raw, n_distinct, numeric(1))
)
save_table(overview, "00_raw_data_overview")

msg("Imported ", nrow(raw), " rows, ", ncol(raw), " columns")
print(overview, n = Inf)
