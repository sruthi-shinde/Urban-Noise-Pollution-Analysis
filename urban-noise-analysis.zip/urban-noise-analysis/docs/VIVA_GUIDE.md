# Viva Preparation Guide

## 30-second pitch
"I built an R pipeline that cleans hourly noise data from 12 stations, tests what explains noise levels, ranks hotspots against India's legal
noise limits, and automatically detects abnormal noise events. The anomaly detector was validated against known injected events."

## Likely questions and answers
**Why is the dataset simulated?** Continuous hourly multi-station data is rarely open. The simulator follows traffic-noise physics
(level = a + ~9 log10 traffic), adds weather, shifts and holidays, then corrupts the data like real sensors. Injected events give ground truth, so
cleaning and anomaly detection can be *measured*. The pipeline accepts real CSVs (README: "Using real data").

**Why Leq instead of mean dB?** dB is logarithmic; loud moments dominate energy. Mean of dB understates exposure. Leq = 10 log10(mean(10^(L/10))).

**What are L10, L50, L90?** Levels exceeded 10%, 50%, 90% of the time (percentiles 90, 50, 10). L10 - L90 is the "noise climate" (variability).

**Why non-parametric tests?** Shapiro-Wilk and Q-Q plots show non-normality. Kruskal-Wallis / Wilcoxon only use ranks.
With n of about 100,000 almost anything is "significant", so I report effect sizes (epsilon-squared, dB differences).

**Why paired tests on station-days?** Hourly values are autocorrelated (violating independence). Aggregating to station-day Leq and pairing day with night at the same station reduces that problem.

**Why is the regression good (R2 about 0.91)? Is it overfitted?** Evaluated on unseen Oct-Dec data (test R2 about the same as train), so no. Strong fit is expected because the traffic-noise relationship is physical. VIF shows traffic is correlated with night/day (VIF about 8), so I interpret coefficients cautiously.

**Why do temperature and humidity correlate with noise but not in the regression?** Both follow the daily cycle, as does traffic. Controlling for traffic removes the spurious link (confounding).

**How does the anomaly detector work?** Three methods: robust z-score and IQR fence against the station's own hour/weekend baseline, plus regression residuals. An hour is flagged when at least 2 agree; consecutive flagged hours (at least 2 h) become an event. Recall about 96%, precision about 64%; the false alarms are mostly short, mild events, tunable via `CFG$anomaly`.

**Why not just a threshold like 85 dB?** Normal noise differs by place and hour; 60 dB is abnormal at 3 a.m. in a hospital zone but normal in a market at noon. Baselines are contextual.

**How were hotspots scored?** Weighted min-max composite (40% excess over limit, 40% exceedance share, 20% Noise Pollution Level). Weights are a design choice and can be changed; the ranking is robust at the top.

**How did you handle missing data?** Gaps up to 3 hours: linear interpolation (flagged); longer gaps left NA and excluded, never invented. Invalid readings (outside 30-130 dB) set to NA.

**What would you do with real data?** Calibrate/validate sensors, use real traffic counts, account for spatial correlation between stations, consider time-series models (e.g. ARIMA/GAM) and spatial interpolation.

## Honest limitations to volunteer
Simulated data; autocorrelation; collinearity; synthetic coordinates; anomaly precision about 64% with default thresholds.
